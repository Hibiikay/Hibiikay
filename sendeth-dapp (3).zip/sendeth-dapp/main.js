import { ethers } from "ethers";

let provider;
let signer;
let account;

// Contract details (for voting)
const contractAddress = "0x35cd167FA931C6c5E07AbB2621846FC35D54baD6";
const abi = [
  "function vote(uint proposal) public"
];

// Connect Wallet
document.getElementById("connectBtn").onclick = async () => {
  if (window.ethereum) {
    provider = new ethers.BrowserProvider(window.ethereum);
    await provider.send("eth_requestAccounts", []);
    signer = await provider.getSigner();
    account = await signer.getAddress();

    document.getElementById("account").innerText = account;

    let balance = await provider.getBalance(account);
    document.getElementById("balance").innerText = ethers.formatEther(balance);
  } else {
    alert("MetaMask not detected!");
  }
};

// Send ETH
document.getElementById("sendBtn").onclick = async () => {
  if (!signer) return alert("Please connect wallet first.");

  const to = document.getElementById("toAddress").value;
  const amount = document.getElementById("ethAmount").value;

  try {
    const tx = await signer.sendTransaction({
      to: to,
      value: ethers.parseEther(amount)
    });
    await tx.wait();
    alert(`Transaction successful! Hash: ${tx.hash}`);
  } catch (err) {
    alert("Transaction failed: " + err.message);
  }
};

// Voting
async function vote(proposal) {
  if (!signer) return alert("Please connect wallet first.");

  const contract = new ethers.Contract(contractAddress, abi, signer);

  try {
    const tx = await contract.vote(proposal);
    await tx.wait();
    alert(`Successfully voted for Proposal ${proposal}!`);
  } catch (err) {
    alert("Voting failed: " + err.message);
  }
}

document.getElementById("vote1Btn").onclick = () => vote(1);
document.getElementById("vote2Btn").onclick = () => vote(2);
