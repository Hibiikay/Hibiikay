window.addEventListener("DOMContentLoaded", () => {
  let provider, signer;
  const connectBtn = document.getElementById("connectBtn");
  const accountEl = document.getElementById("account");
  const balanceEl = document.getElementById("balance");
  const sendBtn = document.getElementById("sendBtn");
  const vote1Btn = document.getElementById("vote1");
  const vote2Btn = document.getElementById("vote2");

  const votingAddress = "0x35cd167FA931C6c5E07AbB2621846FC35D54baD6";
  const votingAbi = [ "function vote(uint256 proposal) external" ];

  async function connectWallet() {
    if (!window.ethereum) {
      alert("MetaMask not detected. Please install MetaMask.");
      return;
    }
    try {
      provider = new ethers.BrowserProvider(window.ethereum);
      await provider.send("eth_requestAccounts", []);
      signer = await provider.getSigner();
      const address = await signer.getAddress();
      accountEl.textContent = `Connected: ${address}`;
      updateBalance();
    } catch (err) {
      console.error(err);
      alert("Failed to connect wallet.");
    }
  }

  async function updateBalance() {
    if (!signer) return;
    const address = await signer.getAddress();
    const balanceBigInt = await provider.getBalance(address);
    balanceEl.textContent = `Balance: ${ethers.formatEther(balanceBigInt)} ETH`;
  }

  async function sendETH() {
    if (!signer) { alert("Connect wallet first"); return; }
    const to = document.getElementById("toAddress").value.trim();
    const amount = document.getElementById("amount").value;
    if (!to || !amount) { alert("Provide recipient and amount"); return; }

    try {
      const tx = await signer.sendTransaction({
        to,
        value: ethers.parseEther(amount)
      });
      await tx.wait();
      alert("Transaction confirmed!");
      updateBalance();
    } catch (err) {
      console.error(err);
      alert("Transaction failed.");
    }
  }

  async function vote(proposal) {
    if (!signer) { alert("Connect wallet first"); return; }
    const contract = new ethers.Contract(votingAddress, votingAbi, signer);
    try {
      const tx = await contract.vote(proposal);
      await tx.wait();
      alert(`Voted for Proposal ${proposal}!`);
    } catch (err) {
      console.error(err);
      alert("Vote failed.");
    }
  }

  connectBtn.addEventListener("click", connectWallet);
  sendBtn.addEventListener("click", sendETH);
  vote1Btn.addEventListener("click", () => vote(1));
  vote2Btn.addEventListener("click", () => vote(2));
});
